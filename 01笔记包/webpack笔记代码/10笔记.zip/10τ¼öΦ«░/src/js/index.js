import '../css/style.css';
import '../css/bootstrap.css';

let a = 10;
console.log(a);
