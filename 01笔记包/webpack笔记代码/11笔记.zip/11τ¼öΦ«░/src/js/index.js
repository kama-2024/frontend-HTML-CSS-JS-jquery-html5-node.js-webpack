import '../css/style.css';
import '../css/bootstrap.css';
import $ from 'jquery'

$("div").css("background","red");

$("p").css("color","blue");

let a = 10;

console.log(a);